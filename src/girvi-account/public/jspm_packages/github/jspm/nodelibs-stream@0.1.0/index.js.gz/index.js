/* */ 
module.exports = System._nodeRequire ? System._nodeRequire('stream') : require('stream-browserify');
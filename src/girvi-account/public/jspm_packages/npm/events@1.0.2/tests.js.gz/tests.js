/* */ 
module.exports = require('./tests/index');

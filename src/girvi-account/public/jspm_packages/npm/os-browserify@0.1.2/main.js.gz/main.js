/* */ 
module.exports = require('os');

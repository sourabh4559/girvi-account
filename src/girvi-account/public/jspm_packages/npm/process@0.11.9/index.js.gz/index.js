// for now just expose the builtin process global from node.js
module.exports = global.process;
